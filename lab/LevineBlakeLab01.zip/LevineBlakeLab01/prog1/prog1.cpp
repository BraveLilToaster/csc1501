#include <iostream>
using namespace std;

/**
 * outputs the string CSC 1501 2015 Winter, Hello World and a line break
 */
int main(){
    cout << "CSC 1501 2015 Winter, Hello World" << endl;
}
